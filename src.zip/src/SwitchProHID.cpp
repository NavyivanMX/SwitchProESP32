// ============================================================
// SwitchProESP32
// ------------------------------------------------------------
// Archivo : SwitchProHID.cpp
// Función : Implementación Bluetooth HID.
// ============================================================

#include "SwitchProHID.h"
#include "SwitchProDescriptor.h"

#include "esp_bt.h"
#include "esp_bt_main.h"
#include "esp_hidd_api.h"
#include "esp_err.h"
#include "esp_log.h"


// ============================================================
// TAG
// ============================================================

static const char* TAG = "SwitchProHID";


// ============================================================
// Constructor
// ============================================================

SwitchProHID::SwitchProHID()
    : m_inputReport()
{
}


// ============================================================
// HID CALLBACK
// ============================================================

void SwitchProHID::hidCallback(
    esp_hidd_cb_event_t event,
    esp_hidd_cb_param_t* param)
{
    ESP_LOGI(
        TAG,
        "HID event: %d",
        static_cast<int>(event)
    );


    if (param == nullptr)
    {
        return;
    }


    // --------------------------------------------------------
    // El host envió un Output Report
    // --------------------------------------------------------

    if (event == ESP_HIDD_SET_REPORT_EVT)
    {
        handleOutputReport(param);
    }
}


// ============================================================
// HANDLE OUTPUT REPORT
// ============================================================

void SwitchProHID::handleOutputReport(
    const esp_hidd_cb_param_t* param)
{
    if (param == nullptr)
    {
        return;
    }


    ESP_LOGI(
        TAG,
        "========================================"
    );

    ESP_LOGI(
        TAG,
        "HID OUTPUT REPORT RECEIVED"
    );


    // --------------------------------------------------------
    // Información del reporte
    // --------------------------------------------------------

    ESP_LOGI(
        TAG,
        "Report ID: %u",
        param->set_report.report_id
    );


    ESP_LOGI(
        TAG,
        "Report type: %u",
        param->set_report.report_type
    );


    ESP_LOGI(
        TAG,
        "Report length: %u",
        param->set_report.len
    );


    // --------------------------------------------------------
    // Mostrar datos recibidos
    // --------------------------------------------------------

    if (
        param->set_report.data != nullptr &&
        param->set_report.len > 0
    )
    {
        ESP_LOG_BUFFER_HEX(
            TAG,
            param->set_report.data,
            param->set_report.len
        );
    }
    else
    {
        ESP_LOGI(
            TAG,
            "Report contains no data"
        );
    }


    ESP_LOGI(
        TAG,
        "========================================"
    );
}


// ============================================================
// BEGIN
// ============================================================

bool SwitchProHID::begin()
{
    ESP_LOGI(
        TAG,
        "========================================"
    );

    ESP_LOGI(
        TAG,
        "SwitchProESP32"
    );

    ESP_LOGI(
        TAG,
        "Bluetooth HID initialization"
    );

    ESP_LOGI(
        TAG,
        "========================================"
    );


    // --------------------------------------------------------
    // 1. Bluetooth Controller
    // --------------------------------------------------------

    if (!initBluetoothController())
    {
        ESP_LOGE(
            TAG,
            "Bluetooth controller initialization failed"
        );

        return false;
    }


    // --------------------------------------------------------
    // 2. Bluedroid
    // --------------------------------------------------------

    if (!initBluedroid())
    {
        ESP_LOGE(
            TAG,
            "Bluedroid initialization failed"
        );

        return false;
    }


    // --------------------------------------------------------
    // 3. HID
    // --------------------------------------------------------

    if (!initHID())
    {
        ESP_LOGE(
            TAG,
            "Bluetooth HID initialization failed"
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "Bluetooth HID: READY"
    );


    return true;
}


// ============================================================
// INIT BLUETOOTH CONTROLLER
// ============================================================

bool SwitchProHID::initBluetoothController()
{
    ESP_LOGI(
        TAG,
        "Initializing Bluetooth controller..."
    );


    esp_bt_controller_config_t btConfig =
        BT_CONTROLLER_INIT_CONFIG_DEFAULT();


    esp_err_t result =
        esp_bt_controller_init(&btConfig);


    if (result != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "esp_bt_controller_init failed: %s",
            esp_err_to_name(result)
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "Bluetooth controller: OK"
    );


    result =
        esp_bt_controller_enable(
            ESP_BT_MODE_CLASSIC_BT
        );


    if (result != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "esp_bt_controller_enable failed: %s",
            esp_err_to_name(result)
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "Bluetooth Classic enabled"
    );


    return true;
}


// ============================================================
// INIT BLUEDROID
// ============================================================

bool SwitchProHID::initBluedroid()
{
    ESP_LOGI(
        TAG,
        "Initializing Bluedroid..."
    );


    esp_err_t result =
        esp_bluedroid_init();


    if (result != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "esp_bluedroid_init failed: %s",
            esp_err_to_name(result)
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "Bluedroid initialized"
    );


    result =
        esp_bluedroid_enable();


    if (result != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "esp_bluedroid_enable failed: %s",
            esp_err_to_name(result)
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "Bluedroid enabled"
    );


    return true;
}


// ============================================================
// INIT HID
// ============================================================

bool SwitchProHID::initHID()
{
    ESP_LOGI(
        TAG,
        "Initializing Bluetooth HID Device..."
    );


    // --------------------------------------------------------
    // Registrar callback
    // --------------------------------------------------------

    esp_err_t result =
        esp_bt_hid_device_register_callback(
            hidCallback
        );


    if (result != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "esp_bt_hid_device_register_callback failed: %s",
            esp_err_to_name(result)
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "HID callback registered"
    );


    // --------------------------------------------------------
    // Inicializar HID
    // --------------------------------------------------------

    result =
        esp_bt_hid_device_init();


    if (result != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "esp_bt_hid_device_init failed: %s",
            esp_err_to_name(result)
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "HID Device initialized"
    );


    // --------------------------------------------------------
    // Parámetros HID
    // --------------------------------------------------------

    esp_hidd_app_param_t appParam{};


    appParam.name =
        const_cast<char*>(
            "SwitchProESP32"
        );


    appParam.description =
        const_cast<char*>(
            "Nintendo Switch Controller"
        );


    appParam.provider =
        const_cast<char*>(
            "SwitchProESP32"
        );


    appParam.subclass = 0x04;


    // --------------------------------------------------------
    // Report Map
    // --------------------------------------------------------

    appParam.desc_list =
        const_cast<uint8_t*>(
            SwitchProDescriptor::ReportMap
        );


    appParam.desc_list_len =
        SwitchProDescriptor::ReportMapSize;


    // --------------------------------------------------------
    // QoS
    // --------------------------------------------------------

    esp_hidd_qos_param_t inQos{};

    esp_hidd_qos_param_t outQos{};


    // --------------------------------------------------------
    // Registrar aplicación
    // --------------------------------------------------------

    result =
        esp_bt_hid_device_register_app(
            &appParam,
            &inQos,
            &outQos
        );


    if (result != ESP_OK)
    {
        ESP_LOGE(
            TAG,
            "esp_bt_hid_device_register_app failed: %s",
            esp_err_to_name(result)
        );

        return false;
    }


    ESP_LOGI(
        TAG,
        "HID application registered"
    );


    return true;
}


// ============================================================
// SEND INPUT REPORT
// ============================================================

bool SwitchProHID::sendInputReport(
    const SwitchProControllerState& state
)
{
    const size_t reportSize =
        m_inputReport.build(state);


    if (reportSize == 0)
    {
        ESP_LOGE(
            TAG,
            "Failed to build HID input report"
        );

        return false;
    }


    ESP_LOGD(
        TAG,
        "HID input report built (%u bytes)",
        static_cast<unsigned>(reportSize)
    );


    return true;
}


// ============================================================
// UPDATE
// ============================================================

void SwitchProHID::update()
{
    // --------------------------------------------------------
    // Por ahora los eventos son manejados por callback.
    // --------------------------------------------------------
}